#LawngTV's Private Server Modpack
=======================
##Simplicity Edition

###Simple Instructions

Contained here is almost all the files needed to run either a client or server with this modpack. I retain none of the distribution or attribution rights to the contents of this repo, and as such encourage you not to download it. Please refer to the [Feed the Beast Vanilla+](http://forum.feed-the-beast.com/threads/vanilla-press-release.93218/) pack if you want an official modpack.

To go against my instructions, simply download the zip file with the link to the right (the button which at the time of this writing says "Download Zip"). Then place the contents into your already working forge modded minecraft directory. If you are using a loader, then in the "instance" that loader created. If you are using the default minecraft launcher, this is likely in your .minecraft folder in your user directory somewhere. If you can't find that, then use [google](https://www.google.com/search?q=Minecraft+folder+location&oq=Minecraft+folder+location).

###Mod List
- 1.7.10/
 - CodeChickenLib-1.7.10-1.1.3.136-universal.jar
 - commons-codec-1.9.jar
 - commons-compress-1.8.1.jar
 - ForgeMultipart-1.7.10-1.2.0.344-universal.jar
 - MrTJPCore-1.0.8.16-universal.jar
- 1.7.10-MB_Battlegear2-Bullseye-1.0.8.0.jar
- AdminCommandsToolbox-0.0.2a_1.7.10.jar
- AgriCraft-1.7.10-1.3.1.jar
- antiqueatlas-4.2.2-1.7.10.jar
- AppleCore-mc1.7.10-1.1.0.jar
- Aroma1997Core-1.7.10-1.0.2.13.jar
- AromaBackup-1.7.10-0.0.0.5.jar.disabled
- BiblioCraft[v1.10.4][MC1.7.10].jar
- BiblioWoods[Natura][v1.5].jar
- carpentersblocks/
 - CarpentersBlocksCachedResources.zip
- Carpenter's Blocks v3.3.6 - MC 1.7.10.jar
- Chisel2-2.3.10.37.jar
- ChiselTones-1.7.10-1.0-1.jar
- CodeChickenCore-1.7.10-1.0.6.43-universal.jar
- compactstorage-1.7.10-release-2.0.0.9-universal.jar
- D3Core-1.7.10-1.1.0.22.jar
- Decocraft-2.1.1_1.7.10.jar
- denseores-1.6.2.jar
- EnderCompass-1.7.10-1.1.jar
- Et Futurum-1.1.1.jar
- ExtraButtons-1.7.10.1.jar
- FastLeafDecay-1.7.10-1.0.jar
- FlatSigns-1.7.10-universal-2.1.0.19.jar
- hopperductmod-1.7.10-1.3.2.jar
- INpureCore-[1.7.10]1.0.0B9-62.jar
- InventoryTweaks-1.59-dev-152.jar
- Jabba-1.2.1a_1.7.10.jar
- JACB-1.7.10-1.0.2.jar
- Ladders-0.5.0-MC1.7.10.jar
- LavaBoat 2.0.0.jar
- Mantle-1.7.10-0.3.2.jar
- MineTweaker3-1.7.10-3.0.9C.jar
- Morpheus-1.7.10-1.6.4.jar
- natura-1.7.10-2.2.0.1.jar
- neiaddons-1.12.9.32-mc1.7.10.jar
- NEIIntegration-MC1.7.10-1.0.10.jar
- NotEnoughItems-1.7.10-1.0.4.107-universal.jar
- Pam's HarvestCraft 1.7.10i.jar
- ProjectRed-1.7.10-4.6.2.82-Base.jar
- ProjectRed-1.7.10-4.6.2.82-Integration.jar
- Railcraft_1.7.10-9.6.1.0.jar
- SpiceOfLife-mc1.7.10-1.2.3.jar
- StevesWorkshop-0.5.1.jar
- StorageDrawers-1.7.10-1.5.5.jar
- TConstruct-1.7.10-1.8.7.jar
- TorchTools-1.7.10-1.2.0.26.jar
- ttCore-MC1.7.10-0.1.0-67.jar
- Waila-1.5.10_1.7.10.jar
- Ztones-1.7.10-2.2.1.jar
